package com.example.fruitworld.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.example.fruitworld.R;
import com.example.fruitworld.Activities.MainActivity;

import java.util.List;

public class MyAdapter extends  BaseAdapter  {

    private Context context;
    private int layout;
    private List<String> frutas;


    public MyAdapter(Context context, int layout, List<String> frutas){
        this.context=context;
        this.layout=layout;
        this.frutas=frutas;
    }

    @Override
    public int getCount(){
        return this.frutas.size();
    }

    @Override
    public  Object getItem(int position){
        return this.frutas.get(position);
    }
    @Override
    public long getItemId(int id){
        return id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup){
        View v = convertView;
        LayoutInflater layoutInflater=LayoutInflater.from(this.context);
        v= layoutInflater.inflate(R.layout.grid_item,null);
        //Traemos el valor actual dependiente de la posición
        String nombre_frutas = frutas.get(position);
        // Referenciamos el elemento a modificar y se rellena
           TextView textView= (TextView)v.findViewById(R.id.textView) ;
         textView.setText(nombre_frutas);
        return v;

    }


}
