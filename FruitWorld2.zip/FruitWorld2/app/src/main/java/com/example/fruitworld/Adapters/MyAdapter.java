package com.example.fruitworld.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.fruitworld.Models.Fruit;
import com.example.fruitworld.R;

import java.util.List;

public class MyAdapter extends ArrayAdapter<Fruit> {

    private Context context;
    private int layout;
    private List<Fruit> frutas;

    public MyAdapter(Context context, int resource, List<Fruit> objects) {
        super(context, resource, objects);
        this.frutas= objects;
        this.context = context;
        this.layout= resource;
    }


    @Override
    public int getCount(){
        return this.frutas.size();
    }


    @Override
    public long getItemId(int id){
        return id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View v = convertView;
        if(v==null)
            v = LayoutInflater.from(context).inflate(R.layout.grid_item, null);


            LayoutInflater layoutInflater=LayoutInflater.from(this.context);
        v= layoutInflater.inflate(R.layout.grid_item,null);
        //Traemos el valor actual dependiente de la posición
        String nombre_frutas = frutas.get(position).getName();
        // Referenciamos el elemento a modificar y se rellena
           TextView textView= (TextView)v.findViewById(R.id.textView) ;
         textView.setText(nombre_frutas);

         Fruit fruit = frutas.get(position);

         ImageView icon = v.findViewById(R.id.imageView);
         icon.setImageResource(fruit.getIcon());

         TextView textoNombre = v.findViewById(R.id.textView);
         textoNombre.setText(fruit.getName());


        return v;

    }


}
