package com.example.fruitworld.Activities;

import
        androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.fruitworld.Adapters.MyAdapter;
import com.example.fruitworld.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<String> frutas;
    private GridView gridView;
    private ListView listamenu;
    private ListView listView;


    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Forzar y cargar icono en el Action Bar
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_icono_app);

        //Se enlaza con el adaptador
        MyAdapter myAdapter = new MyAdapter(this, R.layout.grid_item,frutas);
        listView.setAdapter(myAdapter);

        listView= (ListView) findViewById(R.id.listView);
        listamenu = (ListView) findViewById(R.id.listView);
        gridView=(GridView)findViewById(R.id.gridView);
        //Datos a mostrar
        frutas = new ArrayList<String>();
        frutas.add("Platano");
        frutas.add("Manzana");


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        }
        });

        // Enlazamos con nuestro adaptador personalizado
         myAdapter = new MyAdapter(this, R.layout.grid_item, frutas);
         gridView.setAdapter(myAdapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        return true;
    }







}