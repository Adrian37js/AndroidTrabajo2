package com.example.fruitworld.Activities;

import
        androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import com.example.fruitworld.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<String> names;
    private GridView gridView;
    private ListView listamenu;

    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listamenu = (ListView) findViewById(R.id.listView);
        gridView=(GridView)findViewById(R.id.gridView);

        listamenu.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                listamenu.getMenu().findItem(R.id.listView).setVisible(true);
                listamenu.getMenu().findItem(R.id.listView).setVisible(false);


            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        return true;
    }







}