package com.example.fruitworld.Activities;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fruitworld.Adapters.MyAdapter;
import com.example.fruitworld.Models.Fruit;
import com.example.fruitworld.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private List<Fruit> frutas;
    private GridView gridView;
    private ListView listView;
    private MyAdapter myAdapterList;
    private MyAdapter myAdapterGrid;


    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Forzar y cargar icono en el Action Bar
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.mipmap.ic_icono_app);



        listView= (ListView) findViewById(R.id.listView);
        gridView=(GridView)findViewById(R.id.gridView);
        //Datos a mostrar
        frutas = new ArrayList<Fruit>();


                frutas.add(new Fruit("Banana", R.mipmap.ic_banana, "Gran Canaria"));
                frutas.add(new Fruit("Strawberry", R.mipmap.ic_strawberry, "Huelva"));
                frutas.add(new Fruit("Orange", R.mipmap.ic_orange, "Sevilla"));
                frutas.add(new Fruit("Apple", R.mipmap.ic_apple, "Madrid"));
                frutas.add(new Fruit("Cherry", R.mipmap.ic_cherry, "Galicia"));
                frutas.add(new Fruit("Pear", R.mipmap.ic_pear, "Zaragoza"));
                frutas.add(new Fruit("Raspberry", R.mipmap.ic_raspberry, "Barcelona"));

      //Se enlaza con el adaptador
        myAdapterList = new MyAdapter(this, R.layout.grid_item,frutas);
        listView.setAdapter(myAdapterList);


        registerForContextMenu(listView);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            }
        });

        // Enlazamos con nuestro adaptador personalizado
         myAdapterGrid = new MyAdapter(this, R.layout.grid_item, frutas);
         gridView.setAdapter(myAdapterGrid);
        registerForContextMenu(gridView);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        return true;
    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this, "Elemento clicado: "+i, Toast.LENGTH_SHORT).show();

    }
}
