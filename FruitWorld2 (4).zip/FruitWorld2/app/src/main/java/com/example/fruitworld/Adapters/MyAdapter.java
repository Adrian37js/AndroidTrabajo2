package com.example.fruitworld.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.fruitworld.Models.Fruit;
import com.example.fruitworld.R;

import java.util.List;

public class MyAdapter extends ArrayAdapter<Fruit> {

    private Context context;
    private int layout;
    private List<Fruit> frutas;

    public MyAdapter(Context context, int resource, List<Fruit> objects) {
        super(context, resource, objects);
        this.frutas= objects;
        this.context = context;
        this.layout= resource;
    }


    @Override
    public int getCount(){
        return this.frutas.size();
    }


    @Override
    public long getItemId(int id){
        return id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        //Copiamos la vist
        View v = convertView;
        //Inflamos la vists que nos ha llegado del layout personalizado
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        v= layoutInflater.inflate(R.layout.grid_item,null);
        //Traemos el valor actual dependiente de la posición
        Fruit currentName = frutas.get(position);
        //Referenciamos el elemento a modificar y se rellena
        TextView textView= (TextView)v.findViewById(R.id.textView);
        return v;

    }


    }

